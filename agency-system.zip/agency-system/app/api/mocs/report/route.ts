import { NextRequest, NextResponse } from 'next/server'

const REPORT_PROMPT = `You are generating a formal accountability report for Topside Roofing & Siding's audit of Marketing 360 (Madwire).

Generate a complete, professional Markdown report with:
1. Executive summary
2. Contract overview (what was promised)
3. Findings by breach rule (BR-001 through BR-009 as applicable)
4. Financial impact analysis
5. Evidence index
6. Recommended next steps
7. Conclusion

Use formal but plain language. Be specific about dollar amounts, dates, and metrics where provided. This document may be shown to an attorney.`

export async function POST(req: NextRequest) {
  try {
    const { findings, evidenceIds, additionalContext } = await req.json()

    const userContent = `Generate an accountability report with these findings:

${JSON.stringify(findings, null, 2)}

Evidence on file: ${evidenceIds?.join(', ') || 'EV-RP-001 through EV-RP-008'}

Additional context: ${additionalContext || 'None'}`

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 2048,
        system: REPORT_PROMPT,
        messages: [{ role: 'user', content: userContent }],
      }),
    })

    const data = await response.json()
    const report = data.content
      .filter((b: { type: string }) => b.type === 'text')
      .map((b: { text: string }) => b.text)
      .join('\n')

    return NextResponse.json({ report, generatedAt: new Date().toISOString() })
  } catch (err) {
    console.error('/api/mocs/report error:', err)
    return NextResponse.json({ error: 'Report generation failed' }, { status: 500 })
  }
}
