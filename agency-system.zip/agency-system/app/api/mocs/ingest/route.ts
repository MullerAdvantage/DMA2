import { NextRequest, NextResponse } from 'next/server'
import { writeFileSync, mkdirSync } from 'fs'
import { join } from 'path'

const CATEGORIES = ['billing', 'deliverables', 'seo', 'ads', 'comms'] as const
type Category = typeof CATEGORIES[number]

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File
    const category = (formData.get('category') as Category) || 'billing'
    const evidenceId = formData.get('evidenceId') as string || `EV-${Date.now()}`

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    if (!CATEGORIES.includes(category)) {
      return NextResponse.json({ error: 'Invalid category' }, { status: 400 })
    }

    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    const dir = join(process.cwd(), 'mocs/evidence', category)
    mkdirSync(dir, { recursive: true })

    const filename = `${evidenceId}-${file.name}`
    const filepath = join(dir, filename)
    writeFileSync(filepath, buffer)

    // Write metadata sidecar
    const meta = {
      evidenceId,
      category,
      originalName: file.name,
      size: file.size,
      type: file.type,
      ingestedAt: new Date().toISOString(),
      filepath: `mocs/evidence/${category}/${filename}`,
    }
    writeFileSync(filepath + '.meta.json', JSON.stringify(meta, null, 2))

    return NextResponse.json({ success: true, evidenceId, filepath: meta.filepath })
  } catch (err) {
    console.error('/api/mocs/ingest error:', err)
    return NextResponse.json({ error: 'Ingest failed' }, { status: 500 })
  }
}
