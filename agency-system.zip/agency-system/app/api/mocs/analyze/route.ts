import { NextRequest, NextResponse } from 'next/server'

const FORENSICS_PROMPT = `You are a forensic auditor analyzing marketing agency evidence for Topside Roofing & Siding.

The company has an active audit of Marketing 360 (Madwire) with confirmed breach findings:
- BR-001: Missing deliverables (contracted: 4 blogs, 4 emails, 8 social posts/month)
- BR-002: Billing variance (hidden management fee deducted from ad credits)
- BR-004: Reporting failure
- BR-005: Ad account access denied
- BR-006: SEO decline without explanation (GSC avg position 14 → 23)
- BR-008: Unauthorized hidden fee

Analyze the provided evidence and return a JSON object with this exact structure:
{
  "summary": "2-3 sentence plain-English summary of what this evidence shows",
  "breachesConfirmed": ["BR-001", "BR-008"],
  "newFindings": [{"id": "FINDING-001", "description": "...", "severity": "critical|high|medium|low"}],
  "financialImpact": {"estimated": true, "amount": 0, "description": "..."},
  "recommendedActions": ["action 1", "action 2"],
  "legalWeight": "strong|moderate|weak",
  "evidenceQuality": "high|medium|low",
  "notes": "Any additional observations"
}

Return ONLY valid JSON. No preamble, no markdown fences.`

export async function POST(req: NextRequest) {
  try {
    const { content, filename, category } = await req.json()

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: FORENSICS_PROMPT,
        messages: [{
          role: 'user',
          content: `Analyze this evidence file.\n\nFilename: ${filename}\nCategory: ${category}\n\nContent:\n${content}`,
        }],
      }),
    })

    const data = await response.json()
    const raw = data.content
      .filter((b: { type: string }) => b.type === 'text')
      .map((b: { text: string }) => b.text)
      .join('')

    const clean = raw.replace(/```json|```/g, '').trim()
    const analysis = JSON.parse(clean)

    return NextResponse.json({ analysis })
  } catch (err) {
    console.error('/api/mocs/analyze error:', err)
    return NextResponse.json({ error: 'Analysis failed' }, { status: 500 })
  }
}
