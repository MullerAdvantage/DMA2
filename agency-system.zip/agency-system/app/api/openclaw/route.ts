import { NextRequest, NextResponse } from 'next/server'
import { readFileSync, existsSync } from 'fs'
import { join } from 'path'

export async function POST(req: NextRequest) {
  try {
    const { skill, command, userInput } = await req.json()

    // Load skill system prompt if it exists
    const skillPath = join(process.cwd(), 'openclaw/skills', `${skill}.txt`)
    let skillPrompt = `You are an expert assistant executing the "${skill}" skill for Topside Roofing & Siding.`

    if (existsSync(skillPath)) {
      skillPrompt = readFileSync(skillPath, 'utf-8')
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 2048,
        system: skillPrompt,
        messages: [{
          role: 'user',
          content: command ? `${command}\n\n${userInput || ''}` : userInput,
        }],
      }),
    })

    const data = await response.json()
    const output = data.content
      .filter((b: { type: string }) => b.type === 'text')
      .map((b: { text: string }) => b.text)
      .join('\n')

    return NextResponse.json({ output, skill, command })
  } catch (err) {
    console.error('/api/openclaw error:', err)
    return NextResponse.json({ error: 'Skill execution failed' }, { status: 500 })
  }
}
