'use client'
import { useState } from 'react'

const breachRules = [
  { id: 'BR-001', name: 'Missing Deliverables',      severity: 4, status: 'confirmed', detail: 'Contracted: 4 blogs, 4 emails, 8 social posts/month. Multiple months with partial or zero delivery.' },
  { id: 'BR-002', name: 'Billing Variance',          severity: 5, status: 'confirmed', detail: 'Hidden management fee deducted from "Ad Credits" without contract disclosure. Not authorized in signed agreement.' },
  { id: 'BR-003', name: 'Lead Volume Underperform',  severity: 3, status: 'investigating', detail: 'US conversions down ~76% under active management. Awaiting lead count data.' },
  { id: 'BR-004', name: 'Reporting Failure',         severity: 4, status: 'confirmed', detail: 'No performance reports delivered within contracted timeframe across multiple months.' },
  { id: 'BR-005', name: 'Ad Account Access Denied',  severity: 5, status: 'confirmed', detail: 'Client unable to independently verify ad spend due to lack of platform access.' },
  { id: 'BR-006', name: 'SEO Decline',               severity: 3, status: 'confirmed', detail: 'GSC average position declined from 14.2–14.3 to 22.7–24.4. No explanation provided.' },
  { id: 'BR-007', name: 'Social Underdelivery',      severity: 3, status: 'investigating', detail: 'Contracted 8 posts/month. Auditing post history for delivery counts.' },
  { id: 'BR-008', name: 'Unauthorized Fee',          severity: 5, status: 'confirmed', detail: 'Fee not specified in contract fee schedule. Every instance supports billing fraud narrative.' },
  { id: 'BR-009', name: 'No Response to Inquiry',    severity: 4, status: 'investigating', detail: 'Documented inquiries sent. Tracking response timelines.' },
]

const statusStyle: Record<string, string> = {
  confirmed:    'bg-red-100 text-red-700',
  investigating:'bg-yellow-100 text-yellow-700',
  cleared:      'bg-green-100 text-green-700',
}

const sevColor = (s: number) => {
  if (s >= 5) return 'text-red-600'
  if (s >= 4) return 'text-orange-500'
  return 'text-yellow-600'
}

export default function MocsPage() {
  const [selected, setSelected] = useState(breachRules[0])
  const confirmed = breachRules.filter(b => b.status === 'confirmed').length

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">MOCS Audit</h1>
        <p className="text-sm text-gray-500 mt-1">Marketing Oversight & Compliance System · Marketing 360 (Madwire)</p>
      </div>

      {/* Summary bar */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Confirmed breaches',  value: confirmed,  color: '#DC2626' },
          { label: 'Under investigation', value: breachRules.filter(b => b.status === 'investigating').length, color: '#D97706' },
          { label: 'Evidence files',      value: '8',        color: '#0E2A47' },
          { label: 'Financial risk',      value: '70/100',   color: '#DC2626' },
        ].map(m => (
          <div key={m.label} className="bg-white border border-border rounded-lg p-4">
            <div className="text-2xl font-semibold" style={{ color: m.color }}>{m.value}</div>
            <div className="text-xs text-gray-500 mt-1">{m.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-5 gap-5">
        {/* Breach list */}
        <div className="col-span-2 bg-white border border-border rounded-lg divide-y divide-border">
          {breachRules.map(b => (
            <div
              key={b.id}
              onClick={() => setSelected(b)}
              className={`px-4 py-3 cursor-pointer hover:bg-gray-50 transition-colors ${selected.id === b.id ? 'bg-navy-50 border-l-2' : ''}`}
              style={selected.id === b.id ? { borderLeftColor: 'var(--gold)', background: 'rgba(14,42,71,0.03)' } : {}}
            >
              <div className="flex items-center justify-between">
                <code className="text-xs text-gray-400">{b.id}</code>
                <span className={`text-xs px-2 py-0.5 rounded-full ${statusStyle[b.status]}`}>{b.status}</span>
              </div>
              <div className="text-sm text-gray-800 mt-1">{b.name}</div>
              <div className={`text-xs mt-0.5 ${sevColor(b.severity)}`}>Severity {b.severity}/5</div>
            </div>
          ))}
        </div>

        {/* Detail panel */}
        <div className="col-span-3 bg-white border border-border rounded-lg p-6">
          <div className="flex items-start justify-between mb-3">
            <div>
              <code className="text-sm font-mono text-gray-400">{selected.id}</code>
              <h2 className="text-lg font-semibold text-gray-900 mt-0.5">{selected.name}</h2>
            </div>
            <span className={`text-sm px-3 py-1 rounded-full font-medium ${statusStyle[selected.status]}`}>
              {selected.status}
            </span>
          </div>

          <p className="text-sm text-gray-700 leading-relaxed mb-6">{selected.detail}</p>

          <div className="border-t border-border pt-4">
            <div className="text-xs font-medium text-gray-500 mb-2">Severity</div>
            <div className="flex gap-1">
              {[1,2,3,4,5].map(n => (
                <div
                  key={n}
                  className={`h-2 flex-1 rounded-full ${n <= selected.severity ? 'bg-red-400' : 'bg-gray-100'}`}
                />
              ))}
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <a
              href="/dashboard/reports"
              className="text-xs px-3 py-2 rounded-lg border border-border hover:border-navy text-gray-600 hover:text-navy transition-colors"
            >
              Generate report
            </a>
            <a
              href="/dashboard/evidence"
              className="text-xs px-3 py-2 rounded-lg border border-border hover:border-navy text-gray-600 hover:text-navy transition-colors"
            >
              Upload evidence
            </a>
            <a
              href="/dashboard/bot"
              className="text-xs px-3 py-2 rounded-lg border border-border hover:border-navy text-gray-600 hover:text-navy transition-colors"
            >
              Ask AI bot
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
