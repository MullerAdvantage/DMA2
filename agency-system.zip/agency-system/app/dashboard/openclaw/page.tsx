'use client'
import { useState } from 'react'

const SKILLS = [
  { id: 'mocs',        label: 'MOCS Audit',          desc: 'Marketing 360 forensics and breach detection' },
  { id: 'roofing-ops', label: 'Roofing Ops',         desc: 'Document extraction → QB / Excel / Leap workflow' },
  { id: 'weekly',      label: 'Weekly Report',        desc: 'Marketing performance report generation' },
  { id: 'seo',         label: 'SEO Audit',            desc: 'Competitor analysis and local SEO recommendations' },
  { id: 'estimator',   label: 'Estimator',            desc: 'Job scheduling and estimate assistant' },
  { id: 'knowledge',   label: 'Knowledge Binder',    desc: 'Topside operations and marketing reference' },
]

const COMMANDS: Record<string, string[]> = {
  mocs:        ['/run_full_mocs_setup', '/build_dashboard', '/build_financial_forensics_layer', '/log_daily_activity', '/log_weekly_summary'],
  'roofing-ops':['Process a document', 'Create QB estimate', 'Generate PO number', 'Update Excel log'],
  weekly:      ['Generate weekly report', 'Compare vs M360 reported', 'Identify anomalies'],
  seo:         ['Audit local rankings', 'Monitor competitors', 'Federal Way SEO gap analysis'],
  estimator:   ['Schedule a job', 'Find open slots', 'Import from document'],
  knowledge:   ['What are our service areas?', 'QuickBooks workflow', 'Marketing strategy'],
}

export default function OpenClawPage() {
  const [skill, setSkill] = useState(SKILLS[0].id)
  const [command, setCommand] = useState('')
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [loading, setLoading] = useState(false)

  async function run() {
    setLoading(true)
    setOutput('')
    try {
      const res = await fetch('/api/openclaw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ skill, command, userInput: input }),
      })
      const data = await res.json()
      setOutput(data.output || data.error)
    } catch {
      setOutput('Error executing skill.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">OpenClaw</h1>
        <p className="text-sm text-gray-500 mt-1">Skill executor — run any Topside OS skill directly</p>
      </div>

      <div className="grid grid-cols-5 gap-6">
        {/* Skill selector */}
        <div className="col-span-2 space-y-2">
          {SKILLS.map(s => (
            <div
              key={s.id}
              onClick={() => { setSkill(s.id); setCommand(''); setOutput('') }}
              className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
                skill === s.id
                  ? 'border-navy bg-navy/5'
                  : 'border-border bg-white hover:border-gray-300'
              }`}
            >
              <div className="text-sm font-medium text-gray-900">{s.label}</div>
              <div className="text-xs text-gray-400 mt-0.5">{s.desc}</div>
            </div>
          ))}
        </div>

        {/* Execution panel */}
        <div className="col-span-3 space-y-4">
          {/* Commands */}
          <div className="bg-white border border-border rounded-lg p-5">
            <div className="text-xs font-medium text-gray-500 mb-2">Quick commands</div>
            <div className="flex flex-wrap gap-2">
              {COMMANDS[skill]?.map(cmd => (
                <button
                  key={cmd}
                  onClick={() => setCommand(cmd)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                    command === cmd ? 'border-navy text-navy bg-navy/5' : 'border-border text-gray-600 hover:border-gray-400'
                  }`}
                >
                  {cmd}
                </button>
              ))}
            </div>

            <div className="mt-4">
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder="Add context, paste document text, or type a custom instruction..."
                rows={4}
                className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:border-navy resize-none"
              />
            </div>

            <button
              onClick={run}
              disabled={loading || (!command && !input.trim())}
              className="mt-3 w-full py-2.5 rounded-lg text-sm font-medium text-white disabled:opacity-40"
              style={{ background: 'var(--navy)' }}
            >
              {loading ? 'Running...' : `Run ${SKILLS.find(s2 => s2.id === skill)?.label}`}
            </button>
          </div>

          {/* Output */}
          {(output || loading) && (
            <div className="bg-white border border-border rounded-lg">
              <div className="px-5 py-3 border-b border-border text-xs text-gray-400">Output</div>
              <pre className="p-5 text-sm text-gray-700 whitespace-pre-wrap leading-relaxed font-mono max-h-96 overflow-y-auto">
                {loading ? 'Running skill...' : output}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
