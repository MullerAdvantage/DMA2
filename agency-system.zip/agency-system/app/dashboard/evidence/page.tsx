'use client'
import { useState, useRef } from 'react'

const CATEGORIES = ['billing', 'deliverables', 'seo', 'ads', 'comms'] as const
type Category = typeof CATEGORIES[number]

type UploadResult = {
  evidenceId: string
  filepath: string
  analysis?: {
    summary: string
    breachesConfirmed: string[]
    newFindings: { id: string; description: string; severity: string }[]
    financialImpact: { estimated: boolean; amount: number; description: string }
    recommendedActions: string[]
    legalWeight: string
    evidenceQuality: string
  }
}

const severityColor: Record<string, string> = {
  critical: 'text-red-600',
  high: 'text-orange-500',
  medium: 'text-yellow-600',
  low: 'text-green-600',
}

export default function EvidencePage() {
  const [category, setCategory] = useState<Category>('billing')
  const [evidenceId, setEvidenceId] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [result, setResult] = useState<UploadResult | null>(null)
  const [error, setError] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  async function upload() {
    if (!file) return
    setUploading(true)
    setError('')
    setResult(null)

    try {
      // 1. Ingest
      const form = new FormData()
      form.append('file', file)
      form.append('category', category)
      form.append('evidenceId', evidenceId || `EV-${Date.now()}`)

      const ingestRes = await fetch('/api/mocs/ingest', { method: 'POST', body: form })
      const ingestData = await ingestRes.json()

      if (!ingestData.success) throw new Error(ingestData.error)

      // 2. Analyze (text files only for now)
      let analysis = null
      if (file.type.startsWith('text/') || file.name.endsWith('.csv') || file.name.endsWith('.md')) {
        const text = await file.text()
        const analyzeRes = await fetch('/api/mocs/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ content: text, filename: file.name, category }),
        })
        const analyzeData = await analyzeRes.json()
        analysis = analyzeData.analysis
      }

      setResult({ evidenceId: ingestData.evidenceId, filepath: ingestData.filepath, analysis })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="p-8 max-w-3xl">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Evidence Vault</h1>
        <p className="text-sm text-gray-500 mt-1">Upload files to the MOCS evidence archive. Text files are analyzed automatically.</p>
      </div>

      {/* Upload form */}
      <div className="bg-white border border-border rounded-lg p-6 mb-6">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Category</label>
            <select
              value={category}
              onChange={e => setCategory(e.target.value as Category)}
              className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:border-navy"
            >
              {CATEGORIES.map(c => <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Evidence ID (optional)</label>
            <input
              type="text"
              value={evidenceId}
              onChange={e => setEvidenceId(e.target.value)}
              placeholder="e.g. EV-RP-009"
              className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:border-navy"
            />
          </div>
        </div>

        {/* Drop zone */}
        <div
          onClick={() => inputRef.current?.click()}
          className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-navy transition-colors"
        >
          {file ? (
            <div>
              <div className="text-sm font-medium text-gray-800">{file.name}</div>
              <div className="text-xs text-gray-400 mt-1">{(file.size / 1024).toFixed(1)} KB · {file.type || 'unknown type'}</div>
            </div>
          ) : (
            <div>
              <div className="text-sm text-gray-500">Drop a file or click to browse</div>
              <div className="text-xs text-gray-400 mt-1">CSV, PDF, PNG, MD, TXT accepted</div>
            </div>
          )}
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            onChange={e => setFile(e.target.files?.[0] || null)}
          />
        </div>

        {error && <div className="mt-3 text-sm text-red-600">{error}</div>}

        <button
          onClick={upload}
          disabled={!file || uploading}
          className="mt-4 w-full py-2.5 rounded-lg text-sm font-medium text-white disabled:opacity-40"
          style={{ background: 'var(--navy)' }}
        >
          {uploading ? 'Ingesting & analyzing...' : 'Upload to vault'}
        </button>
      </div>

      {/* Analysis result */}
      {result && (
        <div className="bg-white border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-gray-900">Ingested</h2>
            <code className="text-xs bg-green-50 text-green-700 px-2 py-0.5 rounded">{result.evidenceId}</code>
          </div>
          <div className="text-xs text-gray-400 mb-4 font-mono">{result.filepath}</div>

          {result.analysis && (
            <>
              <p className="text-sm text-gray-700 mb-4">{result.analysis.summary}</p>

              {result.analysis.breachesConfirmed.length > 0 && (
                <div className="mb-3">
                  <div className="text-xs font-medium text-gray-500 mb-1.5">Breaches confirmed</div>
                  <div className="flex gap-2 flex-wrap">
                    {result.analysis.breachesConfirmed.map(b => (
                      <span key={b} className="text-xs bg-red-50 text-red-700 px-2 py-0.5 rounded">{b}</span>
                    ))}
                  </div>
                </div>
              )}

              {result.analysis.newFindings.length > 0 && (
                <div className="mb-3">
                  <div className="text-xs font-medium text-gray-500 mb-1.5">New findings</div>
                  {result.analysis.newFindings.map(f => (
                    <div key={f.id} className="text-sm">
                      <span className={`font-medium ${severityColor[f.severity] || 'text-gray-700'}`}>[{f.severity}]</span>
                      {' '}{f.description}
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-4 text-xs text-gray-500 border-t border-border pt-3 mt-3">
                <span>Legal weight: <strong className="text-gray-700">{result.analysis.legalWeight}</strong></span>
                <span>Evidence quality: <strong className="text-gray-700">{result.analysis.evidenceQuality}</strong></span>
              </div>
            </>
          )}

          {!result.analysis && (
            <p className="text-sm text-gray-500">File stored. Text analysis not available for this file type — upload CSV, MD, or TXT for automatic analysis.</p>
          )}
        </div>
      )}
    </div>
  )
}
