'use client'
import { useState, useRef, useEffect } from 'react'

type Message = { role: 'user' | 'assistant'; content: string }

export default function BotPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Ready. I have full context on the Marketing 360 audit, MOCS findings, and all Topside operations. What do you need?' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function send() {
    const text = input.trim()
    if (!text || loading) return
    setInput('')

    const next: Message[] = [...messages, { role: 'user', content: text }]
    setMessages(next)
    setLoading(true)

    try {
      const res = await fetch('/api/bot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      })
      const data = await res.json()
      setMessages([...next, { role: 'assistant', content: data.reply || data.error }])
    } catch {
      setMessages([...next, { role: 'assistant', content: 'Error contacting API.' }])
    } finally {
      setLoading(false)
    }
  }

  const quickPrompts = [
    '/run_full_mocs_setup',
    '/build_dashboard',
    '/log_daily_activity',
    'Draft the Tyler Hatton email',
    'What are my active breach findings?',
    'Generate a weekly marketing report',
  ]

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <div className="px-8 py-5 border-b border-border bg-white">
        <h1 className="text-lg font-semibold text-gray-900">AI Bot</h1>
        <p className="text-xs text-gray-400 mt-0.5">MOCS-aware audit assistant · claude-sonnet-4-6</p>
      </div>

      {/* Quick prompts */}
      <div className="px-8 py-3 border-b border-border bg-white flex gap-2 flex-wrap">
        {quickPrompts.map(p => (
          <button
            key={p}
            onClick={() => { setInput(p); }}
            className="text-xs px-3 py-1.5 rounded-full border border-border hover:border-navy hover:text-navy transition-colors text-gray-600"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-8 py-6 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-2xl px-4 py-3 rounded-xl text-sm whitespace-pre-wrap leading-relaxed ${
                m.role === 'user'
                  ? 'text-white rounded-br-sm'
                  : 'bg-white border border-border text-gray-800 rounded-bl-sm'
              }`}
              style={m.role === 'user' ? { background: 'var(--navy)' } : {}}
            >
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-border px-4 py-3 rounded-xl rounded-bl-sm">
              <div className="flex gap-1.5">
                <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-8 py-4 border-t border-border bg-white">
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
            placeholder="Ask anything or run a /command..."
            className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm focus:outline-none focus:border-navy"
          />
          <button
            onClick={send}
            disabled={loading || !input.trim()}
            className="px-5 py-2.5 rounded-lg text-sm font-medium text-white disabled:opacity-40 transition-opacity"
            style={{ background: 'var(--navy)' }}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  )
}
