import Link from 'next/link'

const findings = [
  { id: 'BR-001', label: 'Missing deliverables',         severity: 'high',     status: 'Active' },
  { id: 'BR-002', label: 'Billing variance >5%',         severity: 'critical', status: 'Active' },
  { id: 'BR-004', label: 'Reporting failure',            severity: 'high',     status: 'Active' },
  { id: 'BR-005', label: 'Ad account access denied',     severity: 'critical', status: 'Active' },
  { id: 'BR-006', label: 'SEO decline, no explanation',  severity: 'medium',   status: 'Active' },
  { id: 'BR-008', label: 'Unauthorized hidden fee',      severity: 'critical', status: 'Active' },
]

const metrics = [
  { label: 'Financial Risk Score', value: '70/100', sub: 'HIGH', color: '#DC2626' },
  { label: 'Ad Spend Collapse',    value: '−82%',   sub: '~$784 deployed', color: '#D97706' },
  { label: 'GSC Position Drop',    value: '14→23',  sub: 'avg position', color: '#D97706' },
  { label: 'US Conversions Drop',  value: '−76%',   sub: 'under management', color: '#DC2626' },
]

const severityColor: Record<string, string> = {
  critical: 'bg-red-100 text-red-700',
  high:     'bg-orange-100 text-orange-700',
  medium:   'bg-yellow-100 text-yellow-700',
}

export default function DashboardPage() {
  return (
    <div className="p-8 max-w-5xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Topside OS</h1>
        <p className="text-sm text-gray-500 mt-1">Marketing 360 Audit — Active · Evidence IDs EV-RP-001 through EV-RP-008</p>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {metrics.map(m => (
          <div key={m.label} className="bg-white border border-border rounded-lg p-4">
            <div className="text-2xl font-semibold" style={{ color: m.color }}>{m.value}</div>
            <div className="text-xs text-gray-500 mt-0.5">{m.sub}</div>
            <div className="text-xs font-medium text-gray-700 mt-2">{m.label}</div>
          </div>
        ))}
      </div>

      {/* Active breach findings */}
      <div className="bg-white border border-border rounded-lg mb-6">
        <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
          <h2 className="text-sm font-semibold text-gray-900">Active Breach Findings</h2>
          <Link href="/dashboard/mocs" className="text-xs text-blue-600 hover:underline">View full audit →</Link>
        </div>
        <div className="divide-y divide-border">
          {findings.map(f => (
            <div key={f.id} className="px-5 py-3 flex items-center gap-4">
              <code className="text-xs font-mono text-gray-400 w-16">{f.id}</code>
              <span className="flex-1 text-sm text-gray-800">{f.label}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${severityColor[f.severity]}`}>
                {f.severity}
              </span>
              <span className="text-xs text-red-500 font-medium">{f.status}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { href: '/dashboard/mocs',     label: 'Run full MOCS audit',     desc: 'Breach detection + forensics' },
          { href: '/dashboard/evidence', label: 'Upload evidence',          desc: 'Add to EV-RP vault' },
          { href: '/dashboard/reports',  label: 'Generate report',          desc: 'Legal-ready Markdown output' },
          { href: '/dashboard/openclaw', label: 'Run a skill',              desc: 'OpenClaw skill executor' },
          { href: '/dashboard/bot',      label: 'Ask the AI bot',           desc: 'Conversational audit assistant' },
          { href: '/dashboard/reports',  label: 'Tyler Hatton email',       desc: 'Accountability email generator' },
        ].map(a => (
          <Link
            key={a.href + a.label}
            href={a.href}
            className="bg-white border border-border rounded-lg p-4 hover:border-gold hover:shadow-sm transition-all group"
          >
            <div className="text-sm font-medium text-gray-900 group-hover:text-navy">{a.label}</div>
            <div className="text-xs text-gray-400 mt-1">{a.desc}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
