'use client'
import { useState } from 'react'

const DEFAULT_FINDINGS = [
  { id: 'BR-001', label: 'Missing deliverables (blogs, emails, social posts)', severity: 'high', active: true },
  { id: 'BR-002', label: 'Billing variance — hidden management fee', severity: 'critical', active: true },
  { id: 'BR-004', label: 'Reporting failure — no monthly reports delivered', severity: 'high', active: true },
  { id: 'BR-005', label: 'Ad account access denied', severity: 'critical', active: true },
  { id: 'BR-006', label: 'SEO decline without explanation (avg position 14→23)', severity: 'medium', active: true },
  { id: 'BR-008', label: 'Unauthorized fee deducted from ad credits', severity: 'critical', active: true },
]

export default function ReportsPage() {
  const [findings, setFindings] = useState(DEFAULT_FINDINGS)
  const [context, setContext] = useState('')
  const [report, setReport] = useState('')
  const [loading, setLoading] = useState(false)

  function toggle(id: string) {
    setFindings(f => f.map(x => x.id === id ? { ...x, active: !x.active } : x))
  }

  async function generate() {
    setLoading(true)
    setReport('')
    try {
      const res = await fetch('/api/mocs/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          findings: findings.filter(f => f.active),
          evidenceIds: ['EV-RP-001', 'EV-RP-002', 'EV-RP-003', 'EV-RP-004', 'EV-RP-005', 'EV-RP-006', 'EV-RP-007', 'EV-RP-008'],
          additionalContext: context,
        }),
      })
      const data = await res.json()
      setReport(data.report || data.error)
    } catch {
      setReport('Error generating report.')
    } finally {
      setLoading(false)
    }
  }

  function download() {
    const blob = new Blob([report], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `MOCS-Report-${new Date().toISOString().slice(0,10)}.md`
    a.click()
  }

  const severityColor: Record<string, string> = {
    critical: 'bg-red-100 text-red-700',
    high: 'bg-orange-100 text-orange-700',
    medium: 'bg-yellow-100 text-yellow-700',
  }

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Report Generator</h1>
        <p className="text-sm text-gray-500 mt-1">Generate a legal-ready accountability report from confirmed breach findings.</p>
      </div>

      <div className="grid grid-cols-5 gap-6">
        {/* Config */}
        <div className="col-span-2">
          <div className="bg-white border border-border rounded-lg p-5 mb-4">
            <h2 className="text-sm font-semibold text-gray-900 mb-3">Include findings</h2>
            <div className="space-y-2">
              {findings.map(f => (
                <label key={f.id} className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={f.active}
                    onChange={() => toggle(f.id)}
                    className="mt-0.5"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <code className="text-xs text-gray-400">{f.id}</code>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full ${severityColor[f.severity]}`}>{f.severity}</span>
                    </div>
                    <div className="text-xs text-gray-700 mt-0.5">{f.label}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-white border border-border rounded-lg p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-2">Additional context</h2>
            <textarea
              value={context}
              onChange={e => setContext(e.target.value)}
              placeholder="Any additional notes, dates, or context to include..."
              rows={4}
              className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:border-navy resize-none"
            />
          </div>

          <button
            onClick={generate}
            disabled={loading}
            className="mt-4 w-full py-2.5 rounded-lg text-sm font-medium text-white disabled:opacity-40"
            style={{ background: 'var(--navy)' }}
          >
            {loading ? 'Generating...' : 'Generate report'}
          </button>
        </div>

        {/* Report output */}
        <div className="col-span-3">
          <div className="bg-white border border-border rounded-lg h-full min-h-96">
            {report ? (
              <div>
                <div className="px-5 py-3 border-b border-border flex items-center justify-between">
                  <span className="text-xs text-gray-500">Report generated</span>
                  <button onClick={download} className="text-xs text-blue-600 hover:underline">Download .md</button>
                </div>
                <pre className="p-5 text-xs text-gray-700 whitespace-pre-wrap leading-relaxed font-mono overflow-y-auto max-h-screen">
                  {report}
                </pre>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-sm text-gray-400 p-8 text-center">
                {loading ? 'Claude is generating your report...' : 'Select findings and click Generate report'}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
