'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const nav = [
  { label: 'Dashboard',  href: '/dashboard',           icon: '⬛' },
  { label: 'MOCS Audit', href: '/dashboard/mocs',      icon: '🔍' },
  { label: 'Evidence',   href: '/dashboard/evidence',  icon: '📁' },
  { label: 'Reports',    href: '/dashboard/reports',   icon: '📊' },
  { label: 'OpenClaw',   href: '/dashboard/openclaw',  icon: '⚡' },
  { label: 'AI Bot',     href: '/dashboard/bot',       icon: '🤖' },
]

export default function Sidebar() {
  const path = usePathname()

  return (
    <aside
      className="fixed top-0 left-0 h-screen w-56 flex flex-col z-50"
      style={{ background: 'var(--navy)' }}
    >
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/10">
        <div className="text-white font-semibold text-sm tracking-wide">TOPSIDE OS</div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--gold)' }}>
          Roofing & Siding
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {nav.map(({ label, href, icon }) => {
          const active = path === href || (href !== '/dashboard' && path.startsWith(href))
          return (
            <Link
              key={href}
              href={href}
              className={`
                flex items-center gap-2.5 px-3 py-2.5 rounded text-sm transition-all
                ${active
                  ? 'nav-link-active font-medium'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
                }
              `}
            >
              <span className="text-base leading-none">{icon}</span>
              {label}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-white/10">
        <div className="text-xs text-white/30">Jessica Muller</div>
        <div className="text-xs text-white/20 mt-0.5">Bellingham, WA</div>
      </div>
    </aside>
  )
}
